<?php $__env->startSection('1'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('2'); ?>
	<table style="width: 1600px;" align="center">
		<tr>
			<td>
				<div class="col-xs-12" style="margin-top:10px;">
					<div class="col-xs-12 text-center" style="background: #f8f8f8; border-radius: 10px; box-shadow: 0 1px 47px rgb(0, 0, 0); "> 
						<div class="form-group text-center" style="margin-top: 10px !important; "> <a href="<?php echo e(action('b@a')); ?>"><span class="glyphicon glyphicon-home" style="color: #8e8e8e;!important;"></span></a></div>
						<h5><?php if(!empty($b->users)): ?> <?php echo e($b->users); ?> <?php else: ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?> </h5>
						<h6>Saldo saat ini Rp. <?php if(!empty($b->e)): ?> <?php echo e($b->e); ?> <?php else: ?> 0  <?php endif; ?> ,-</h6>
						<table class="table table-active" id="btable">
							<tbody>
							<tr>
								<th>Nomor pesanan/struk</th> 
								<th>Saldo sebelum</th>
								<th>Debet</th>
								<th>Kredit</th> 
								<th>Saldo sesudah</th>
								<th>Date</th>
								<th>Keterangan</th> 
							</tr>
							<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr> 
								<td><?php if(!empty($b->i)): ?> <?php echo e($b->i); ?> <?php else: ?> - <?php endif; ?> </td>
								
								<td><?php if(!empty($b->f)): ?> <?php echo e($b->f); ?>,- <?php else: ?> - <?php endif; ?> </td>
								<td><?php if(!empty($b->b)): ?> <?php echo e($b->b); ?>,- <?php else: ?> - <?php endif; ?></td>
								<td><?php if(!empty($b->c)): ?> <?php echo e($b->c); ?>,- <?php else: ?> - <?php endif; ?></td> 
								<td><?php if(!empty($b->g)): ?> <?php echo e($b->g); ?>,- <?php else: ?> - <?php endif; ?> </td>
								<td><?php if(!empty($b->j)): ?> <?php echo e($b->j); ?> <?php else: ?> - <?php endif; ?> </td>
								<td><?php if(!empty($b->h)): ?> <?php echo e($b->h); ?> <?php else: ?> - <?php endif; ?></td> 
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php if(count($a)<=0): ?>
								<td>- </td>
								<td>-  </td>
								<td>- </td>
								<td>- </td>
								<td>-  </td>
								<td>-</td>
							<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</td>
		</tr>
	</table> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('3'); ?>
	<script> 
        $(document).ready(function () { 
        });        
 
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>