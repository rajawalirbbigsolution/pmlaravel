  
<?php $__env->startSection('2'); ?>
<table style="width: 600px;" align="center">
	<tr>
		<td>
			<div class="col-xs-12" style="margin-top:10px;">  
				<div class="col-xs-8 col-xs-offset-2 text-center"
				     style="background: #f8f8f8; border-radius: 10px; box-shadow: 0 1px 47px rgb(0, 0, 0); ">
 
					<h4 class="text-center" style="color: #022c69; margin:22px;">Pilihan</h4>
					<p><a href="<?php echo e(action('c@a')); ?>" class="label label-published">Timesheet</a></p>  
					<p><a href="<?php echo e(action('d@a')); ?>" class="label label-published">Legalmove</a></p>
					
					
					<p><a href="<?php echo e(action('g@a')); ?>" class="label label-published">Saldo</a></p>
					<p><a href="<?php echo e(action('o@a')); ?>" class="label label-published">Riwayat</a></p> 
					 <?php if((int)$a===2): ?>
				<div style="border-top: dashed 1px #898d9480;" >
					<p style="margin-top: 10px"><a href="<?php echo e(action('j@a')); ?>" class="label label-published">Aktivator      </a></p>
					<p><a href="<?php echo e(action('n@a')); ?>" class="label label-published">Riwayat  </a></p>
					<p><a href="<?php echo e(action('m@a')); ?>" class="label label-published">Refresh Timesheet </a></p>
					<p><a href="<?php echo e(action('m@c')); ?>" class="label label-published">Refresh Legalmove </a></p>
					<p><a href="<?php echo e(action('p@a')); ?>" class="label label-published">List eMateriApp </a></p>
					<p><a href="<?php echo e(action('p@b')); ?>" class="label label-published">List Legalmove </a></p>
					<p><a href="<?php echo e(action('p@c')); ?>" class="label label-published">List Timesheet </a></p>
				</div> 
					<?php endif; ?>
					<p><a href="<?php echo e(url('/')); ?>/logout" class="label label-published">Logout</a></p>
				    </div> 
				</div>
			</div> 
		</td>
	</tr>
</table> 
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('3'); ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>