<?php $__env->startSection('1'); ?>
	<style>
		a:hover{
			color: #898d9491!important;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('2'); ?>
	<table style="width: 800px;" align="center"> 
		<tr>
			<td>   
				<div class="col-xs-12" style="margin-top:10px;">
					<div class="col-xs-8 col-xs-offset-2 text-center"  style="background: #f8f8f8; border-radius: 10px; box-shadow: 0 1px 47px rgb(0, 0, 0); "> 
						<div class="form-group text-left" style="margin-top: 10px !important; "> <a href="<?php echo e(action('b@a')); ?>"><span class="glyphicon glyphicon-arrow-left" style="color: #8e8e8e;!important;"></span></a></div>
						<h4> Legalmove</h4>
						<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<p><a class="label label-published"> <?php echo e($b->username); ?></a></p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($a->links()); ?>

					</div>
				</div>
				</div>
			</td>
		</tr> 
	</table> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('3'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>