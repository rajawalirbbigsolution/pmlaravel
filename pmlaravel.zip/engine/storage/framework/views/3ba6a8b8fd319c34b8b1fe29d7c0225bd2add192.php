<?php $__env->startSection('title'); ?>
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
    <?php echo e(__('standard.e')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugin/FontAwesome/css/font-awesome.min.css')); ?>"/>
<?php $__env->startSection('content'); ?>
    <!-- Registrasi Gagal -->
    <div class="row col-xs-12">
        <p>&nbsp;</p>

        <div class="container col-xs-12">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="panel" style="border-radius: 6px; box-shadow: 0 1px 47px rgb(0, 0, 0); ">
                        <div class="panel-body">
                            <div class="form-group text-center">
                                <img src="<?php echo e(asset('img/icon/information3.png')); ?>" width="150px">
                            </div>
                            <div class="form-group">
                                <h3 style="color: #595959; text-align: center;"><?php echo e(__('standard.e')); ?></h3>
                            </div>
                            <div class="form-group text-center">
                                <a href="<?php echo e(route('home')); ?>" class="btn btn-xs btn-purple"><?php echo e(__('standard.q')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <h1>&nbsp;</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Standard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>