<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class cm  extends Model {
    protected $table = '5c';
}
