<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class im  extends Model {
    protected $table = '5i';
}
