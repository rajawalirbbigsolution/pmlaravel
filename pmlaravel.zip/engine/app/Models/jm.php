<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class jm  extends Model {
    protected $table = '5j';
}
