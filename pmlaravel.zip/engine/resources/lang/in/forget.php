<?php

return [
    '1' => 'पासवर्ड भूल गए',
    '2' => 'पासवर्ड रीसेट',
    '3' => 'EMAIL',
    '4' => 'भेजें',
    '5' => 'Reset Password mail was sent',
    '6' => 'CHECK EMAIL',
    '7' => ''
];
