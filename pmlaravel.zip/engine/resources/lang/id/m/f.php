<?php

return [
    '1' => 'RESET PASSWORD',
    '2' => 'BERIKUT 6 DIGIT PIN RESET PASSWORD',
    '3' => 'Tekan tombol dibawah untuk merubah password',
    '4' => 'RESET',
    '5' => 'Hak Cipta',
    '6' => '',
    '7' => '',
    '8' => '',
    '9' => ''
];
