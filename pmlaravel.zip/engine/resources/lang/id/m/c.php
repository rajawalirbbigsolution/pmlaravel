<?php

return [
    '1' => 'Selamat Datang',
    '2' => 'Akun eMateri App telah dibuat',
    '3' => 'PIN AKTIVASI ANDA',
    '4' => 'Tekan tombol dibawah untuk mulai menggunakan',
    '5' => 'AKTIVASI',
    '6' => 'Hak Cipta',
    '7' => '',
    '8' => '',
    '9' => ''
];
