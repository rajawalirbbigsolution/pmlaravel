<?php

return [
    '1' => 'Buat Akun Saya',
    '2' => 'BUAT AKUN SAYA',
    '3' => 'NAMA DEPAN SAYA',
    '4' => 'Minimal 4 Karakter',
    '5' => 'NAMA DEPAN SAYA',
    '6' => 'NAMA BELAKANG SAYA',
    '7' => 'EMAIL SAYA',
    '8' => 'PASSWORD',
    '9' => 'ANDA ADALAH?',
    '10' => 'RESEARCHER',
    '11' => 'DOSEN',
    '12' => 'GURU',
    '13' => 'PELAJAR',
    '14' => 'MAHASISWA',
    '15' => 'UMUM',
    '16' => 'PENULIS',
    '17' => 'PUBLISHER',
    '18' => 'LAINNYA',
    '19' => 'BUAT AKUN',
    '20' => '',
    '21' => ''
];
