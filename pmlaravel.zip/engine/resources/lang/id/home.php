<?php

return [
    '1' => 'Gratis',
    '2' => 'Author : ',
    's' => 'SERING DILIHAT',
    'm' => 'SESUAI MINAT',
    'b' => 'Buka',

];
