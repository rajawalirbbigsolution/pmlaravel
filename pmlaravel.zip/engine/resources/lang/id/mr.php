<?php

return [
    '1' => 'Balas Pesan',
    '2' => 'Pesan',
    '3' => 'Balas',
    '4' => 'Saya',
    '5' => '',
    '6' => '',
    '7' => '',
    '8' => ''
];
