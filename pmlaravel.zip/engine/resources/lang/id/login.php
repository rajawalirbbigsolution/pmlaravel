<?php

return [
    '1' => 'Diterima',
    '2' => 'Username Tidak Teregistrasi',
    '3' => 'Username Tidak Teraktivasi',
    '4' => 'Password Salah',
    '5' => 'Login',
    '6' => 'EMAIL',
    '7' => 'PASSWORD',
    '8' => 'LOGIN',
    '9' => 'BUAT AKUN SAYA',
    '10' => 'Sign Menggunakan',
    '11' => 'LUPA PASSWORD',
    '12' => 'Sukses',
    '13' => '',
    '14' => '',
    '15' => ''
];
