<?php

return [
    '1' => 'Followed',
    '2' => 'BOOK',
    '3' => 'CREATOR',
    '4' => 'Tidak ada author yang disimpan',
    '5' => 'Yakin menghapus?',
    '6' => 'Ya',
    '7' => 'Tidak',
    '8' => 'Hapus',
    '9' => '',
    '10' => '',
    '11' => '',
    '12' => ''
];
