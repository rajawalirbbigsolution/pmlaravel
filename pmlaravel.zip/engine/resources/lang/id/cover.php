<?php

return [
    '1' => 'Sampul',
    '2' => 'Sampul',
    '3' => 'Template',
    '4' => 'Unggah',
    '5' => 'TETAPKAN',
    '6' => 'Unggah Cover',
    '7' => 'TETAPKAN',
    '8' => '',
    '9' => ''
];
