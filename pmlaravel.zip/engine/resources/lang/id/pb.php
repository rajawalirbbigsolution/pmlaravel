<?php

return [
    '1' => 'Background Materi',
    '2' => 'Latar belakang',
    '3' => 'Template',
    '4' => 'Unggah',
    '5' => 'TETAPKAN',
    '6' => 'Upload Background',
    '7' => 'TETAPKAN',
    '8' => 'Latar belakang di halaman utama',
    '9' => 'Latar belakang di halaman detail',
    '10' => ''
];
