<?php

return [
    '1' => 'Pencarian',
    '2' => 'Pencarian belum menemukan hasil.',
    '3' => 'Gratis',
    '4' => 'Private',
    '5' => 'Buka',
    '6' => 'NOTIFIKASI',
    '7' => 'LIHAT MATERI TERLEBIH DAHULU',
    '8' => 'Pencarian berdasarkan kategori',
    '9' => 'Pencarian berdasarkan judul',
    '10' => 'Pencarian berdasarkan author',
    '11' => '',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
