<?php

return [
    '1' => 'Menu Akses',
    '2' => 'Menu Akses',
    '3' => 'MASUKKAN PIN PEMBELI',
    '4' => 'DOWNLOAD',
    '5' => 'LIHAT',
    '6' => 'BERIKAN AKSES',
    '7' => 'NAMA',
    '8' => 'ACTION',
    '9' => 'LIHAT',
    '10' => '',
    '11' => ''
];
