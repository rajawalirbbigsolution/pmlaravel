<?php
return [
    'a' => 'Tentang',
    'b' => 'eMateri App merupakan singkatan dari e (elektronik) dan material. Fungsi aplikasi web ini adalah untuk menyebarkan pengetahuan personal.',
    'c' => 'Fungsi',
    'd' => 'UMUM/PELAJAR',
    'e' => 'PENGAJAR/DOSEN',
    'f' => 'PENULIS/PENERBIT',
    'g' => 'RESEARCHER',
    'h' => 'Dapatkan pengetahuan langsung dari orangnya.',
    'i' => 'Terkoneksi dengan berbagai orang yang membuat ilmu pengetahuan.',
    'j' => 'Fleksibel dibanding ke perpustakaan. And mendapatkan pengetahuan tepat saat anda butuhkan.',
    'k' => 'Dapatkan konten terbaik untuk kebutuhan mengajar.',
    'l' => 'Bandingkan metode pengajaran.',
    'm' => 'Terhubung dengan berbagai pengajar lain dan temukan peluang untuk berkolaborasi.',
    'n' => 'Komersialisasi buku dengan cara paling efisian.',
    'o' => 'Ketahui secara langsung buku mana yang paling disukai oleh pembaca.',
    'p' => 'Terhubung dengan berbagai penulis potensial.',
    'q' => 'Komersialisasikan hasil riset yang anda lakukan melalui publikasi komersial di eMateri App.',
    'r' => 'Dapatkan inspirasi dari orang lain.',
    's' => 'Terhubung dengan berbagai orang yang berkecimpung di bidang yang sama.'
];
