<?php

return [
    '1' => 'Harga Materi',
    '2' => 'Title Package',
    '3' => 'SIMPAN',
    '4' => 'Pengguna membeli materi melalui layanan',
    '5' => 'dengan mata uang Dollar U.S',
    '6' => '',
    '7' => ''
];
