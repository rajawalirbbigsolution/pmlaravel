<?php

return [
    '1' => '1. Untuk publikasi komersil konten wajib original hak cipta sendiri, bukan merupakan hak cipta orang lain.',
    '2' => '2. Apabila ada pelanggaran hak cipta, eMateri akan menghapus konten tersebut. Bila ternyata konten telah dimonetisasi, pemilik akun wajib memberikan hasil penjualan kepada pemilik resmi.',
    '3' => '3. Sebelum publishing disetujui, konten akan diperiksa terlebih dahulu oleh Tim Perlindungan Konsumen untuk memverifikasi konten dan kesesuaian dengan harga yang diberikan, dll.',
    '4' => '3. Pemilik konten bebas menjual dengan harga berapa pun asalkan harga tersebut sesuai.',
    '5' => '4. Biaya akan dihitung setelah 30 penjualan pertama. Biaya yang akan di bebankan adalah 4% dari harga paket.',
    '6' => '5. Pemilik konten dapat menentukan model penjualan dengan bebas, seperti penjualan dengan mengijinkan pengguna untuk mendownload konten, atau hanya dapat dilihat di website, dan lainnya.',
    '7' => '6. eMateri App tidak memperbolehkan pengisian konten yang bermuatan negatif dan apapun yang terkait dengan itu.',
    '8' => 'Aturan Publikasi : ',
    '9' => '',
    '10' => ''
];
