<?php

return [
    '1' => 'Selamat datang di eMateri App. Sekarang anda dapat mulai menggunakan eMateri App.',
    '2' => '',
    '3' => ''
];
