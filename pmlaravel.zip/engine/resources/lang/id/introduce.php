<?php
return [
    '1' => 'Perkenalan',
    '2' => 'PEMBACA',
    '3' => 'PENERBIT',
    '4' => 'Dapatkan Buku atau ilmu pengetahuan dari semua orang. Langsung dari penulis atau penerbit',
    '5' => 'Simpan Buku atau ilmu ke Perpustakaan Anda',
    '6' => 'Dapatkan Pembaruan, Penulis atau Penerbit dapat langsung memperbarui buku',
    '7' => 'MULAI LIHAT BUKU',
    '8' => 'Alat Penerbitan Terpadu',
    '9' => 'Setel Harga',
    '10' => 'Berikan Akses Buku ke Pelanggan',
    '11' => 'MULAI MENERBITKAN',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
