<?php

return [
    '1' => 'Followed',
    '2' => 'BOOK',
    '3' => 'CREATOR',
    '4' => 'Follow belum ada',
    '5' => 'Yakin menghapus?',
    '6' => 'Ya',
    '7' => 'Tidak',
    '8' => 'Hapus',
    '9' => 'Tidak ada buku yang disimpan',
    '10' => '',
    '11' => '',
    '12' => ''
];
