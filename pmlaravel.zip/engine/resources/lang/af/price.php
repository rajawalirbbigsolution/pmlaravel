<?php

return [
    '1' => 'Prys Materi',
    '2' => 'Titel Pakket',
    '3' => 'SAVE',
    '4' => 'Kliënt koop materi via',
    '5' => 'met geldeenheid Dollar U.S.',
    '6' => '',
    '7' => ''
];
