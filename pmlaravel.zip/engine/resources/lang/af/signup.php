<?php

return [
    '1' => 'Skep rekening',
    '2' => 'SKEP REKENING',
    '3' => 'EERSTE NAAM',
    '4' => '4 Karakter Minimum',
    '5' => 'EERSTE NAAM',
    '6' => 'VAN',
    '7' => 'EMAIL',
    '8' => 'WAGWOORD',
    '9' => 'EK MIS?',
    '10' => 'NAVORSER',
    '11' => 'DOSENT',
    '12' => 'ONDERWYSER',
    '13' => 'STUDENT',
    '14' => 'COLLEGE STUDENT',
    '15' => 'GENERAL',
    '16' => 'SKRYWER',
    '17' => 'UITGEWER',
    '18' => 'ANDER',
    '19' => 'CREATE ACCOUNT',
    '20' => '',
    '21' => ''
];
