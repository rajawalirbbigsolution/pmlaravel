<?php
return [
    '1' => 'Stel',
    '2' => 'LESER',
    '3' => 'UITGEWER',
    '4' => 'Kry Boek of wetenskap van alle mense. Direk van skrywer of uitgewer',
    '5' => 'Stoor boek of wetenskap na u biblioteek',
    '6' => 'Kry opgedateer, skrywer of uitgewer aangeskakel om die boek by te werk',
    '7' => 'AANSKAKEL BESKOU BOEK',
    '8' => 'Geïntegreerde Publishing Tool',
    '9' => 'Stel prys',
    '10' => 'Grant kliënt om toegang te verkry tot die boek',
    '11' => 'AANSKAKEL PUBLISEER',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
