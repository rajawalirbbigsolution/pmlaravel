<?php

return [
    '1' => 'Soek',
    '2' => 'Geen resultaat',
    '3' => 'Gratis',
    '4' => 'Privaat',
    '5' => 'oop',
    '6' => 'KENNISGEWING',
    '7' => 'MATERI EERSTE',
    '8' => 'Soekresultaat gebaseerde kategorie',
    '9' => 'Soekresultate gebaseer titel',
    '10' => 'Soekresultaat Gebaseer Naam van Skrywer',
    '11' => '',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
