<?php

return [
    '1' => 'Aanvaar',
    '2' => 'Gebruikersnaam nie geregistreer nie',
    '3' => 'Gebruikersnaam nie geaktiveer nie',
    '4' => 'Verkeerde wagwoord',
    '5' => 'Teken aan',
    '6' => 'EMAIL',
    '7' => 'Wagwoord',
    '8' => 'TEKEN AAN',
    '9' => 'SKEP REKENING',
    '10' => 'Teken met',
    '11' => 'WAGWOORD VERGEET',
    '12' => 'Sukses'
];
