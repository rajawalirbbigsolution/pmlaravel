<?php

return [
    '1' => 'Welcome to eMateri App. Now you can start using the app. Don\'t forget to give feedback about your experience.',
    '2' => '',
    '3' => '',
    '4' => ''
];
