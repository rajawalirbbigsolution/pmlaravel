<?php

return [
    '1' => 'Vry',
    '2' => 'GEPUBLISEER ',
    's' => 'MEES BESIGTIGDE',
    'm' => 'RENTE',
    'b' => 'Oop'
];
