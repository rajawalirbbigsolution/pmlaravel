<?php

return [
    '1' => 'Antwoord Boodskap',
    '2' => 'Boodskap',
    '3' => 'Antwoord',
    '4' => 'My',
    '5' => '',
    '6' => '',
    '7' => '',
    '8' => ''
];
