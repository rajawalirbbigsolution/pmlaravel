<?php

return [
    '1' => 'Toegangslys',
    '2' => 'Toegangslys',
    '3' => 'PIN KLANT',
    '4' => 'AFLAAI',
    '5' => 'BESKOU',
    '6' => 'VERLEEN TOEGANG',
    '7' => 'NAAM',
    '8' => 'AKSIE',
    '9' => 'BESKOU',
    '10' => '',
    '11' => ''
];
