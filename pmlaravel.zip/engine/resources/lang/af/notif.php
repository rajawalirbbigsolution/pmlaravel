<?php

return [
    '1' => 'Kennisgewing',
    '2' => 'Geen kennisgewing',
    '3' => 'Verwyder alles',
    '4' => 'Verwyder',
    '5' => 'Geen',
    '6' => 'Ja',
    '7' => 'Kan nie verwyder nie',
    '8' => 'Kan nie verwyder nie',
    '9' => 'Gered',
    '10' => 'Kan nie stoor nie',
    '11' => '',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
