<?php

return [
    '1' => 'Agtergrond Materi',
    '2' => 'Kies Ontwerp of Laai aangepaste agtergrond op',
    '3' => 'KIES ONTWERP AGTERGROND',
    '4' => 'KLIK AGTERGROND',
    '5' => 'Stel as agtergrond',
    '6' => 'Laai agtergrond',
    '7' => 'UPLOAD DAN SET AS AGTERGROND',
    '8' => 'Voorskou agtergrond op Home',
    '9' => 'Voorskou agtergrond op Materi',
    '10' => ''
];
