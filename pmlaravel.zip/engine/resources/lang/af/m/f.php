<?php

return [
    '1' => 'HERSTEL WAGWOORD',
    '2' => '6 DIGIT PIN RESET PASSWORD',
    '3' => 'Druk die knoppie hieronder om te begin gebruik',
    '4' => 'RESET',
    '5' => 'Kopiereg',
    '6' => '',
    '7' => '',
    '8' => '',
    '9' => ''
];
