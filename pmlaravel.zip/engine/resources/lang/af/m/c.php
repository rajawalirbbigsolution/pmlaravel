<?php

return [
    '1' => 'Welkom',
    '2' => 'eMateri App rekening is geskep',
    '3' => 'JOU AKTIVERING PIN',
    '4' => 'Druk die knoppie hieronder om te begin gebruik',
    '5' => 'AKTIVERING',
    '6' => 'Kopiereg',
    '7' => '',
    '8' => '',
    '9' => ''
];
