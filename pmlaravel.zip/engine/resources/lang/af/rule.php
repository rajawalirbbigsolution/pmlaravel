<?php

return [
    '1' => '1. Vir kommersiële publiseer inhoud moet oorspronklike, geen kopiereg probleem, nie die skepping van ander mense.',
    '2' => '2. As gevind kopiereg probleem, eMateri sal ons die inhoud uitvee.',
    '3' => '3. Voordat publikasie toegelaat word, sal inhoud deur die Consumer Protection Guard-span hersien word.',
    '4' => '3. Eienaar kan die inhoud verkoop word.',
    '5' => '4. Geen koste om inhoud te publiseer nie.',
    '6' => '5. Eienaar kan vryelik verkoopmetode kies.',
    '7' => '6. eMateri App nie toegelaat negatiewe inhoud en enigiets wat daarmee verband hou.',
    '8' => 'Reglement publikasie : ',
    '9' => '',
    '10' => ''
];
