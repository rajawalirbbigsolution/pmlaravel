<?php

return [
    '1' => 'Wagwoord vergeet',
    '2' => 'HERSTEL WAGWOORD',
    '3' => 'EMAIL',
    '4' => 'STUUR',
    '5' => 'Reset Password mail was sent',
    '6' => 'CHECK EMAIL',
    '7' => ''
];
