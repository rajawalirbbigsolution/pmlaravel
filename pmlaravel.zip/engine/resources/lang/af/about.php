<?php
return [
    'a' => 'Oor',
    'b' => 'eMateri App is afkorting van e (elektronies) en materiaal. Die doel van die web app is deel persoonlike kennis.',
    'c' => 'Funksie',
    'd' => 'GENERAL/STUDENT',
    'e' => 'ONDERWYSER/DOSENT',
    'f' => 'SKRYWER/UITGEWER',
    'g' => 'NAVORSER',
    'h' => 'Kry wetenskap direk van mense.',
    'i' => 'Gekoppel met ander mense met dieselfde skryfbelang.',
    'j' => 'Buigsame as wat jy na die openbare biblioteek gaan. Jy kan kennis kry wanneer jy dit nodig het.',
    'k' => 'Kry die beste inhoud vir onderrigdoeleindes.',
    'l' => 'Vergelyk onderrigmetode.',
    'm' => 'Gekoppel met ander onderwyser en vind uit die geleentheid om saam te werk',
    'n' => 'Kommersialiseer boek met doeltreffende manier.',
    'o' => 'Kry die mees gewilde boek.',
    'p' => 'Verbind met potensiële skrywer.',
    'q' => 'Kommersialiseer eie navorsing deur kommersiële publikasie op eMateri App.',
    'r' => 'Kry inspireer van ander mense.',
    's' => 'Gekoppel met ander mense dieselfde werk van navorsing.'
];
