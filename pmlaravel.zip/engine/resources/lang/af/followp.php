<?php

return [
    '1' => 'Gevolg',
    '2' => 'BOEK',
    '3' => 'SKEPPER',
    '4' => 'Volg Skepper Leeg',
    '5' => 'Sure Verwyder?',
    '6' => 'Ja',
    '7' => 'Geen',
    '8' => 'Verwyder',
    '9' => '',
    '10' => '',
    '11' => '',
    '12' => ''
];
