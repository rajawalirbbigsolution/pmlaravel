<?php

return [
    '1' => 'Aktivering',
    '2' => 'AKTIVERING',
    '3' => 'EMAIL',
    '4' => '4 DIGIT PIN',
    '5' => 'Teken aan',
    '6' => 'Aktivering Sukses',
    '7' => 'TEKEN AAN',
];
