<?php

return [
    '1' => 'Registrasie suksesvol, aktiveer per email.',
    '2' => 'Aktivering eMateri App',
    '3' => 'Email Reeds',
    '4' => 'Wagwoord is Suksesvol Verander.',
    '5' => 'Rekening nie geaktiveer nie.',
    '6' => 'Verkeerde Wagwoord.',
    '7' => 'Materi is verwyder',
    '8' => 'Materi kan nie uitvee nie, inhoud nog beskikbaar',
    '9' => 'Login vir toegang tot versoek',
    '10' => 'Verandering is gestoor',
    '11' => 'Ontvolg Suksesvol',
    '12' => 'Dankie, die versoek is gestuur en sal binnekort wees. No ID Versoek',
    '13' => 'Rekening is Geaktiveer',
    '14' => 'VERKEERDE PIN',
    '15' => 'Herstel Wagwoord eMateri App',
    '16' => 'Email nie gevind nie',
    '17' => 'Herstel Wagwoord Verval',
    '18' => 'Daar is geen versoek om die wagwoord te verander nie',
    '19' => 'Wagwoord is Suksesvol Verander'
];
