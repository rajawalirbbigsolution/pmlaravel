<?php

return [
    '1' => 'Cover Materi',
    '2' => 'Kies Ontwerp Dekking of Laai Gepasmaakde Dekking',
    '3' => 'KIES ONTWERP COVER',
    '4' => 'KLANTDEKKING',
    '5' => 'SET AS COVER',
    '6' => 'Laai dekking op',
    '7' => 'UPLOAD EN SET AS COVER',
    '8' => '',
    '9' => ''
];
