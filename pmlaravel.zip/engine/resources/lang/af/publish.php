<?php

return [
    '1' => 'Publishing Tool',
    '2' => 'Skep publikasie',
    '3' => 'Noem Materi',
    '4' => 'Max.',
    '5' => 'TITEL',
    '6' => 'DRAAG NA UPLOAD',
    '7' => 'TERUG',
    '8' => 'VOLGENDE',
    '9' => 'Publishing Succeed',
    '10' => 'OPEN MATERI',
    '11' => 'Titel Materi Leeg',
    '12' => 'Geen inhoud om te publiseer nie',
    '13' => 'Tik titel vir gepubliseer Materi',
    '14' => 'eMateri App ondersteun enige lêer',
    '15' => 'Vir lêer tipe PDF en MP4, kan dokument live op web vertoon',
    '16' => '',
    '17' => '',
    '18' => '',
    '19' => '',
    '20' => '',
    '21' => '',
    '22' => ''
];
