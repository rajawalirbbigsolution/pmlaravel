<?php

return [
    '1' => 'Gevolg',
    '2' => 'Volg Leeg',
    '3' => 'BOEK',
    '4' => 'MENSE',
    '5' => 'Verwyder',
    '6' => 'Sure Verwyder?',
    '7' => 'Ja',
    '8' => '',
    '9' => '',
    '10' => '',
    '11' => '',
    '12' => '',
    '13' => ''
];
