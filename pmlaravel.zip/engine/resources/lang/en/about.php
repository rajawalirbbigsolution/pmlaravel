<?php
return [
    'a' => 'About',
    'b' => 'eMateri App is abbreviation from e (electronic) and material. The purpose of web app is share personal knowledge.',
    'c' => 'Function',
    'd' => 'GENERAL/STUDENT',
    'e' => 'TEACHER/LECTURER',
    'f' => 'WRITER/PUBLISHER',
    'g' => 'RESEARCHER',
    'h' => 'Get knowledge direct from people.',
    'i' => 'Connected with other people with same writing interest.',
    'j' => 'Flexible than you go to public library. You can get knowledge when you need.',
    'k' => 'Get best content for teaching purpose.',
    'l' => 'Compare teaching method.',
    'm' => 'Connected with other teacher and find out opportunity to collaborate',
    'n' => 'Commercialize book with efficient way.',
    'o' => 'Get know most liked book.',
    'p' => 'Connected with potential writer.',
    'q' => 'Commercialize own research using Commercial Publishing on eMateri App.',
    'r' => 'Get inspire from other people.',
    's' => 'Connected with other people that same work of research.'
];
