<?php

return [
    '1' => 'Background Materi',
    '2' => 'Choose Design or Upload Custom Background',
    '3' => 'CHOOSE DESIGN BACKGROUND',
    '4' => 'CUSTOM BACKGROUND',
    '5' => 'SET AS BACKGROUND',
    '6' => 'Upload Background',
    '7' => 'UPLOAD DAN SET AS BACKGROUND',
    '8' => 'Preview Background on Home',
    '9' => 'Preview Background on Materi',
    '10' => ''
];
