<?php

return [
    '1' => 'Price Materi',
    '2' => 'Title Package',
    '3' => 'SAVE',
    '4' => 'Customer buy materi via',
    '5' => 'with currency Dollar U.S.',
    '6' => '',
    '7' => ''
];
