<?php

return [
    '1' => 'Followed',
    '2' => 'Follow Empty',
    '3' => 'BOOK',
    '4' => 'PEOPLE',
    '5' => 'Delete',
    '6' => 'Sure Delete?',
    '7' => 'Yes',
    '8' => '',
    '9' => '',
    '10' => '',
    '11' => '',
    '12' => '',
    '13' => ''
];
