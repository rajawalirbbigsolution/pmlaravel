<?php

return [
    '1' => 'Cover Materi',
    '2' => 'Choose Design Cover or Upload Custom Cover',
    '3' => 'CHOOSE DESIGN COVER',
    '4' => 'CUSTOM COVER',
    '5' => 'SET AS COVER',
    '6' => 'Upload Cover',
    '7' => 'UPLOAD AND SET AS COVER',
    '8' => '',
    '9' => ''
];
