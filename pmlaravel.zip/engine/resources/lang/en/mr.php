<?php

return [
    '1' => 'Reply Message',
    '2' => 'Message',
    '3' => 'Reply',
    '4' => 'Me',
    '5' => '',
    '6' => '',
    '7' => '',
    '8' => ''
];
