<?php

return [
    'f1' => 'Accepted',
    'f2' => 'Username Not Registered',
    'f3' => 'Username Not Activated',
    'f4' => 'Wrong Password',
    'f5' => 'Empty Password',
];
