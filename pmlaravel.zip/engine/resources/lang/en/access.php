<?php

return [
    '1' => 'Access Menu',
    '2' => 'Access Menu',
    '3' => 'PIN CUSTOMER',
    '4' => 'DOWNLOAD',
    '5' => 'VIEW',
    '6' => 'GRANT ACCESS',
    '7' => 'NAME',
    '8' => 'ACTION',
    '9' => 'VIEW',
    '10' => '',
    '11' => ''
];
