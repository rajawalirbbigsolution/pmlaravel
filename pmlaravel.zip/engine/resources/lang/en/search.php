<?php

return [
    '1' => 'Search',
    '2' => 'No Result',
    '3' => 'Free',
    '4' => 'Private',
    '5' => 'Open',
    '6' => 'NOTIFICATION',
    '7' => 'VIEW MATERI FIRST',
    '8' => 'Search Result Based Category',
    '9' => 'Search Result Based Title',
    '10' => 'Search Result Based Name of Author',
    '11' => '',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
