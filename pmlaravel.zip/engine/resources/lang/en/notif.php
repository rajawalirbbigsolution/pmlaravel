<?php

return [
    '1' => 'Notification',
    '2' => 'No Notification',
    '3' => 'Delete All',
    '4' => 'Delete',
    '5' => 'No',
    '6' => 'Yes',
    '7' => 'Can\'t Delete',
    '8' => 'Can\'t Delete',
    '9' => 'Saved',
    '10' => 'Can\'t Save',
    '11' => '',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
