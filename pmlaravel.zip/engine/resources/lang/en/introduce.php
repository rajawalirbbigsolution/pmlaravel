<?php
return [
    '1' => 'Introduce',
    '2' => 'READER',
    '3' => 'PUBLISHER',
    '4' => 'Get Book or science from all of people. Direct from writer or publisher',
    '5' => 'Save Book or science to Your Library',
    '6' => 'Get Updated, Writer or Publisher Enabled to update the book',
    '7' => 'START VIEW BOOK',
    '8' => 'Integrated Publishing Tool',
    '9' => 'Set Price',
    '10' => 'Grant Customer to Access Book',
    '11' => 'START PUBLISH',
    '12' => '',
    '13' => '',
    '14' => '',
    '15' => ''
];
