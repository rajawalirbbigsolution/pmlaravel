<?php

return [
    '1' => 'Accepted',
    '2' => 'Username Not Registered',
    '3' => 'Username Not Activated',
    '4' => 'Wrong Password',
    '5' => 'Login',
    '6' => 'EMAIL',
    '7' => 'PASSWORD',
    '8' => 'LOGIN',
    '9' => 'CREATE ACCOUNT',
    '10' => 'Sign With',
    '11' => 'FORGOT PASSWORD',
    '12' => 'Success'
];
