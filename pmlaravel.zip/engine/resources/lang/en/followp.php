<?php

return [
    '1' => 'Followed',
    '2' => 'BOOK',
    '3' => 'CREATOR',
    '4' => 'Follow Creator Empty',
    '5' => 'Sure Delete?',
    '6' => 'Yes',
    '7' => 'No',
    '8' => 'Delete',
    '9' => '',
    '10' => '',
    '11' => '',
    '12' => ''
];
