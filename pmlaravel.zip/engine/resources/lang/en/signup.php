<?php

return [
    '1' => 'Create Account',
    '2' => 'CREATE ACCOUNT',
    '3' => 'FIRST NAME',
    '4' => '4 Character Minimum',
    '5' => 'FIRST NAME',
    '6' => 'LAST NAME',
    '7' => 'EMAIL',
    '8' => 'PASSWORD',
    '9' => 'I\'M IS?',
    '10' => 'RESEARCHER',
    '11' => 'LECTURER',
    '12' => 'TEACHER',
    '13' => 'STUDENT',
    '14' => 'COLLEGE STUDENT',
    '15' => 'GENERAL',
    '16' => 'WRITER',
    '17' => 'PUBLISHER',
    '18' => 'OTHER',
    '19' => 'CREATE ACCOUNT',
    '20' => '',
    '21' => ''
];
