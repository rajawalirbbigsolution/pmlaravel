<?php

return [
    '1' => 'Publishing Tool',
    '2' => 'Create Publication',
    '3' => 'Name Materi',
    '4' => 'Max.',
    '5' => 'TITLE',
    '6' => 'DRAG TO UPLOAD',
    '7' => 'BACK',
    '8' => 'NEXT',
    '9' => 'Publishing Succeed',
    '10' => 'OPEN MATERI',
    '11' => 'Title Materi Empty',
    '12' => 'No Content to Publish',
    '13' => 'Type Title For Published Materi',
    '14' => 'eMateri App support any file',
    '15' => 'For file type PDF and MP4, document can view live on web',
    '16' => '',
    '17' => '',
    '18' => '',
    '19' => '',
    '20' => '',
    '21' => '',
    '22' => ''
];
