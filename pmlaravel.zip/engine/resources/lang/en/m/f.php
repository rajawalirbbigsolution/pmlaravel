<?php

return [
    '1' => 'RESET PASSWORD',
    '2' => '6 DIGIT PIN RESET PASSWORD',
    '3' => 'Press button below to start use',
    '4' => 'RESET',
    '5' => 'Copyright',
    '6' => '',
    '7' => '',
    '8' => '',
    '9' => ''
];
