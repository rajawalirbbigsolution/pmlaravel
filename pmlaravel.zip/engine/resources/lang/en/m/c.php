<?php

return [
    '1' => 'Welcome',
    '2' => 'eMateri App account was created',
    '3' => 'YOUR ACTIVATION PIN ',
    '4' => 'Press button below to start use',
    '5' => 'ACTIVATION',
    '6' => 'Copyright',
    '7' => '',
    '8' => '',
    '9' => ''
];
