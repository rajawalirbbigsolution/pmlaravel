<?php

return [
    '1' => 'Free',
    '2' => 'PUBLISHED ',
    's' => 'MOST VIEWED',
    'm' => 'INTEREST',
    'b' => 'Open'
];
