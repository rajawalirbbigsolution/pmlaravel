<?php

return [
    '1' => '1. For commercial publish content must be original, no copyright issue, and not creation of the other people.',
    '2' => '2. If found copyright issue, eMateri app will be delete the content.',
    '3' => '3. Every commercial publication may be reviewed by Consumer Protection Guard Team. For quality vs price checking.',
    '4' => '3. Owner can be sold the content.',
    '5' => '4. Charge will be counted after 30 first sale. Charge price is 4% of price per package.',
    '6' => '5. Owner can choose selling method freely.',
    '7' => '6. eMateri App not allowed negative content and anything related with that.',
    '8' => 'Rule of Publication : ',
    '9' => '',
    '10' => ''
];
