@extends('layouts.app')  
@section('2')
<table style="width: 600px;" align="center">
	<tr>
		<td>
			<div class="col-xs-12" style="margin-top:10px;">  
				<div class="col-xs-8 col-xs-offset-2 text-center"
				     style="background: #f8f8f8; border-radius: 10px; box-shadow: 0 1px 47px rgb(0, 0, 0); ">
 
					<h4 class="text-center" style="color: #022c69; margin:22px;">privilages</h4>
						
						
						
					<p><a href="{{action('c@a')}}" class="label label-published">Buat User</a></p>   
						
						<div style="background: #3d3535!important; padding: 10px; border-radius: 5px;">
								<div class="form-group">	<input type="text" placeholder="Nama User" class="form-control" ></div>
								<div class="form-group">	<button class="label label-published">Buat</button></div>  
						</div>
				
				          <table class="table  ">
						          <th style="font-weight: bold;">
								          <td>Nama User</td>
								          <td>Action</td>
						          </th>
						          <tr>
								          <td>User 1</td>
								          <td><button class="label label-published">Edit Privilages </button></td>
						          </tr>
				          </table>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
				    </div> 
				</div>
			</div> 
		</td>
	</tr>
</table> 
		
		
		
		
@endsection 
@section('3') 
@endsection
