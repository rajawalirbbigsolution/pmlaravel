requirejs.config({
    baseUrl : "plugin",
    path : {

    }
});
